package com.example.demo.controllers;




import com.example.demo.controllers.repositori.GitarRepo;
import com.example.demo.json_model.GitarJsonOut;
import com.example.demo.json_model.GitarSache;
import com.example.demo.model.Gitar;
import com.example.demo.sqlRespons.SQL;
import com.solidfire.gson.Gson;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import java.sql.SQLException;
import java.util.List;
import java.util.Objects;

@RestController
public class RestControllerIO {

    @Autowired
    private GitarRepo postMain;

    private SQL sql = new SQL();

    public RestControllerIO() throws SQLException {
    }

    @GetMapping("/get")
    public String submit(){


        return "name";
    }
    @GetMapping("/get_gitar_start")
    public String getGitarStart() throws SQLException {

        Gson gson = new Gson();

        List<Gitar> gitArr = null;

        gitArr = (List<Gitar>) postMain.findAll();

        GitarJsonOut gsonOut = new GitarJsonOut();

        for (int i = 0; i < gitArr.size(); i++) {
            Gitar g = gitArr.get(i);
            gsonOut.git.add(new GitarJsonOut.GitarS(g.getName(),g.getPrice(),g.getType(),g.getSensors()));

        }




        String jsonOut = gson.toJson(gsonOut);



        return jsonOut;
    }

    @PostMapping("/get_gitar")
    public String getGitar(@RequestBody String json) throws SQLException {



        Gson gson = new Gson();
        GitarSache git = gson.fromJson(json, GitarSache.class);
        List<Gitar> gitArr = null;
        //List<Gitar> gitArr = sql.getGitar(git.priceMin, git.priceMax, git.sensorsGit,git.typeGit);

        if(Objects.equals(git.sathInPrice, "up")) {


            if (git.sensorsGit.size() == 0 && git.typeGit.size() == 0) {
                gitArr = postMain.findByPriceUp(git.priceMin, git.priceMax);
            } else if (git.sensorsGit.size() != 0 && git.typeGit.size() == 0) {
                gitArr = postMain.findByPriceAndSensorsUp(git.priceMin, git.priceMax, git.sensorsGit);
            } else if (git.sensorsGit.size() != 0 && git.typeGit.size() != 0) {
                gitArr = postMain.findByPriceAndSensorsAndTypeUp(git.priceMin, git.priceMax, git.sensorsGit, git.typeGit);
            } else if (git.sensorsGit.size() == 0 && git.typeGit.size() != 0) {
                gitArr = postMain.findByPriceAndTypeUp(git.priceMin, git.priceMax, git.typeGit);
            }
        }else if(Objects.equals(git.sathInPrice, "daun")){
            if (git.sensorsGit.size() == 0 && git.typeGit.size() == 0) {
                gitArr = postMain.findByPriceDaun(git.priceMin, git.priceMax);
            } else if (git.sensorsGit.size() != 0 && git.typeGit.size() == 0) {
                gitArr = postMain.findByPriceAndSensorsDaun(git.priceMin, git.priceMax, git.sensorsGit);
            } else if (git.sensorsGit.size() != 0 && git.typeGit.size() != 0) {
                gitArr = postMain.findByPriceAndSensorsAndTypeDaun(git.priceMin, git.priceMax, git.sensorsGit, git.typeGit);
            } else if (git.sensorsGit.size() == 0 && git.typeGit.size() != 0) {
                gitArr = postMain.findByPriceAndTypeDaun(git.priceMin, git.priceMax, git.typeGit);
            }
        }




        GitarJsonOut gsonOut = new GitarJsonOut();

        for (int i = 0; i < gitArr.size(); i++) {
            Gitar g = gitArr.get(i);
            gsonOut.git.add(new GitarJsonOut.GitarS(g.getName(),g.getPrice(),g.getType(),g.getSensors()));

        }




        String jsonOut = gson.toJson(gsonOut);



        return jsonOut;

    }


    @PostMapping("/post")
    public String trasd(@RequestBody String name)  {



       return name;

    }





}
