package com.example.demo.controllers.repositori;


import com.example.demo.model.StudioEquipment;
import org.springframework.data.repository.CrudRepository;

public interface StudioEquipmentRepo extends CrudRepository<StudioEquipment, Long> {
}
