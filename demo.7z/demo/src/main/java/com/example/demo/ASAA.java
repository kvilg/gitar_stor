package com.example.demo;

import com.example.demo.model.Gitar;
import com.solidfire.gson.Gson;
import org.apache.tomcat.util.json.JSONParser;
import org.apache.tomcat.util.json.ParseException;

import java.util.ArrayList;
import java.util.List;

public class ASAA {
    public static void main(String[] args) throws ParseException {





    }
}
