



//    nextArrAA.forEach((next) => {
//     next.addEventListener('click', () => {
//         console.log("next_treu");
//         console.log(next);
//         createGitar(jsonAllG , next);
//     })
// });