package com.example.demo.json_model;

public class GitarJson {

    public Integer minPrice;
    public Integer maxPrice;
    public String acoustic;
    public String electro;
    public String electroacoustics;
    public String activeSensors ;
    public String passiveSensors;

}
