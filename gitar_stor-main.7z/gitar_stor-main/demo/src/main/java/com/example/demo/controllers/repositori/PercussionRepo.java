package com.example.demo.controllers.repositori;

import com.example.demo.model.Percussion;
import org.springframework.data.repository.CrudRepository;

public interface PercussionRepo extends CrudRepository<Percussion, Long> {

}
