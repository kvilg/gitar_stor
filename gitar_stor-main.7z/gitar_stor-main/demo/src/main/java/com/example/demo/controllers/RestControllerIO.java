package com.example.demo.controllers;




import com.example.demo.controllers.repositori.GitarRepo;
import com.example.demo.json_model.GitarJsonOut;
import com.example.demo.json_model.GitarSache;
import com.example.demo.model.Gitar;
import com.example.demo.sqlRespons.SQL;
import com.solidfire.gson.Gson;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import java.sql.SQLException;
import java.util.List;

@RestController
public class RestControllerIO {

    @Autowired
    private GitarRepo postMain;

    private SQL sql = new SQL();

    public RestControllerIO() throws SQLException {
    }

    @GetMapping("/get")
    public String submit(){


        return "name";
    }

    @PostMapping("/get_gitar")
    public String getGitar(@RequestBody String json) throws SQLException {



        Gson gson = new Gson();
        GitarSache git = gson.fromJson(json, GitarSache.class);

        List<Gitar> gitArr = sql.getGitar(git.priceMin, git.priceMax, git.sensorsGit,git.typeGit);

        GitarJsonOut gsonOut = new GitarJsonOut();

        for (int i = 0; i < gitArr.size(); i++) {
            Gitar g = gitArr.get(i);
            gsonOut.git.add(new GitarJsonOut.GitarS(g.getName(),g.getPrice(),g.getType(),g.getSensors()));

        }




        String jsonOut = gson.toJson(gsonOut);



        return jsonOut;

    }


    @PostMapping("/post")
    public String trasd(@RequestBody String name)  {



       return name;

    }





}
