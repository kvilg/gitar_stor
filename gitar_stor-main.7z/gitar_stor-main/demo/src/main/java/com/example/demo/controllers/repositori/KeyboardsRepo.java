package com.example.demo.controllers.repositori;

import com.example.demo.model.Keyboards;
import org.springframework.data.repository.CrudRepository;

public interface KeyboardsRepo extends CrudRepository<Keyboards, Long> {

}
