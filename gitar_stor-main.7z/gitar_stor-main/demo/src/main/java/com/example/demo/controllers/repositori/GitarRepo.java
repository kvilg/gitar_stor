package com.example.demo.controllers.repositori;

import com.example.demo.model.Gitar;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;

public interface GitarRepo extends CrudRepository<Gitar, Long> {

    List<Gitar> findByName(String name);

    @Query(
            value = "SELECT * FROM gitar u WHERE u.price >= :minPrice and u.price <= :maxPrice",
            nativeQuery = true)
    List<Gitar> findByPrice(@Param("minPrice")Integer minPrice,
                                         @Param("maxPrice")Integer maxPrice);


    @Query(
            value = "SELECT * FROM gitar u WHERE u.price >= :minPrice and u.price <= :maxPrice and u.type IN :type",
            nativeQuery = true)
    List<Gitar> findByPriceAndType(@Param("minPrice")Integer minPrice,
                                   @Param("maxPrice")Integer maxPrice,
                                   @Param("type") Collection<String> type);


    @Query(
            value = "SELECT * FROM gitar u WHERE u.price >= :minPrice and u.price <= :maxPrice and u.sensors IN :sensors",
            nativeQuery = true)
    List<Gitar> findByPriceAndSensors(@Param("minPrice")Integer minPrice,
                                      @Param("maxPrice")Integer maxPrice,
                                      @Param("sensors") Collection<String> sensors);

    @Query(
            value = "SELECT * FROM gitar u WHERE u.price >= :minPrice and u.price <= :maxPrice and u.sensors IN :sensors and u.type IN :type",
            nativeQuery = true)
    List<Gitar> findByPriceAndSensorsAndType(@Param("minPrice")Integer minPrice,
                                             @Param("maxPrice")Integer maxPrice,
                                             @Param("sensors") Collection<String> sensors,
                                             @Param("type") Collection<String> type);







    List<Gitar> findByPriceLessThan(Integer price);

    List<Gitar> findByPriceGreaterThan(Integer price);
}
