package com.example.demo.json_model;

import java.util.List;

public class GitarSache {
    public Integer priceMin;
    public Integer priceMax;
    public List<String> typeGit;
    public List<String> sensorsGit;
}
