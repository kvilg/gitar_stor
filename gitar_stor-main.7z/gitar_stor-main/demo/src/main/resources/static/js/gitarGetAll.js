

const GITminPrise = document.getElementById('input_text1');
const GITmaxPrise = document.getElementById('input_text2');

var xhr = new XMLHttpRequest();


var jsonN = JSON.stringify({
    priceMin: +GITminPrise.value,
    priceMax: +GITmaxPrise.value,
    typeGit: [],
    sensorsGit:[]
});


xhr.open("POST", '/get_gitar', true);

xhr.setRequestHeader('Content-Type', 'application/json; charset=utf-8');
xhr.send(jsonN);

xhr.onreadystatechange = function() {
    add(xhr.responseText);
}



function add(str) {
    console.log(str);
}


