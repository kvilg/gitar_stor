const sliders = document.querySelectorAll('input[type="range"]');
const div = document.getElementById('input_text1');
const div1 = document.getElementById('input_text2');
const carl = document.querySelector('.carl');
const btn_sach_gitar = document.querySelector('.btn_sach_gitar');


const minPrise = document.getElementById('input_text1');
const maxPrise = document.getElementById('input_text2');

const gitarAkustic = document.getElementById('gitarAkustic');
const gitarElectro = document.getElementById('gitarElectro');
const gitarElectroAkustic = document.getElementById('gitarElectroAkustic');

const gitarAktivSens = document.getElementById('gitarAktivSens');
const gitarPassivSens = document.getElementById('gitarPassivSens');

let jsonAllG ;

sliders[0].addEventListener('input', (e) => {
    if (+sliders[0].value + 200 > +sliders[1].value) {
        sliders[1].value = +sliders[0].value + 20000;
    }
});

sliders[1].addEventListener('input', (e) => {
    if (+sliders[1].value - 200 < +sliders[0].value) {
        sliders[0].value = +sliders[1].value - 20000;
    }
});

sliders.forEach((slider) => {
    slider.addEventListener('input', () => {
        div.value = `${sliders[0].value}`;
        div1.value = `${sliders[1].value}`;
    })
});


minPrise.addEventListener('change', () => {
    sliders[0].value = minPrise;
});

maxPrise.addEventListener('change', () => {
    sliders[1].value = maxPrise;
});


btn_sach_gitar.addEventListener('click', () => {
    

    var xhr = new XMLHttpRequest();

    let typeArr = [];
    
    

    


    if(gitarAkustic.checked){
        typeArr.push("акустическа");
    }
    if(gitarElectro.checked){
        typeArr.push("электро");
    }
    if(gitarElectroAkustic.checked){
        typeArr.push("электро-акустика");
    }

    

    let sensorsArr = [];

    if(gitarAktivSens.checked){
        sensorsArr.push("активные");
    }
    if(gitarPassivSens.checked){
        sensorsArr.push("пасивные");
    }
 

    

    
    var json = JSON.stringify({
        priceMin: +minPrise.value,
        priceMax:  +maxPrise.value,
        typeGit: typeArr,
        sensorsGit:sensorsArr
    });


    xhr.open("POST", '/get_gitar', true);

    xhr.setRequestHeader('Content-Type', 'application/json; charset=utf-8');
    xhr.send(json);

    xhr.onreadystatechange = function() {
        jsonAllG = xhr.responseText;
        console.log(xhr.responseText);

    

        createGitar(xhr.responseText,1);




       
 

    }
    
    
});


