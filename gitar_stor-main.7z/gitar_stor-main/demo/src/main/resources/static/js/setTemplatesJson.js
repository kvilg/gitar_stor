
function createGitar(txt , namIn) {
    const mainP = document.getElementById('inNewParam');

    console.log(txt);

    let obj = JSON.parse(txt);

    namI =namIn * 5;
    
    let strHtml = ``;

    //console.log(namI-5);
    //console.log(namI);

    //obj.git.length
    try{
        for(i = +(namI-5) ; i<+namI ; i++){
            if(i<obj.git.length){
                strHtml +=   `<div class="product_i">
                    <div class="product_info">
                        <div class="product_name">
                            `+obj.git[i].nameGit+`
                        </div>
                        <div class="product_price">
                            `+obj.git[i].priceGit+`
                        </div>
                        <div class="product_type">
                            `+obj.git[i].sensorsGit+`
                        </div>
                        <div class="product_sens">
                            `+obj.git[i].typeGit+`
                        </div>

                        <!-- 
                        <div class="btn_product_characteristic">

                        </div>
                        -->

                        </div>
                        <div class="product_img">

                        </div>

                    </div>`;
            }   
        }


    }catch{
        
    }
  
    mainP.innerHTML = strHtml;

    const btnSut = document.getElementById('product_next');


    let strHtmlNew = ``;
    
    

    console.log(Math.ceil((+(obj.git.length)/5)));

    for(i = 1 ; i <= Math.ceil(+((obj.git.length)/5)) ; i++){
        if(+namIn == i){
            strHtmlNew += `  <div class="nam_next aktiv" id="next_param">`+i+`</div>`;
        }else{
            strHtmlNew += `  <div class="nam_next" id="next_param">`+i+`</div>`;
        }
    }
    btnSut.innerHTML = strHtmlNew; 


    const nextArrAA = document.querySelectorAll('.nam_next');


  
    //console.log("next");


    nextArrAA.forEach((next) => {
        next.addEventListener('click', () => {
            createGitar(txt,+(next.innerText));
        });
    });

    
   
   



}


