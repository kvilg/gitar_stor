
function createGitar(txt) {
    const mainP = document.getElementById('inNewParam');

    let obj = JSON.parse(txt);

    
    
    let strHtml = ``;

    for(i = 0 ; i<obj.git.length ; i++){
        strHtml +=   `<div class="product_i">
        <div class="product_info">
            <div class="product_name">
                `+obj.git[i].nameGit+`
            </div>
            <div class="product_price">
                `+obj.git[i].priceGit+`
            </div>
            <div class="product_type">
                `+obj.git[i].sensorsGit+`
            </div>
            <div class="product_sens">
                `+obj.git[i].typeGit+`
            </div>

            <!-- 
            <div class="btn_product_characteristic">

            </div>
            -->

        </div>
        <div class="product_img">

        </div>

    </div>`;
    }


    
  
    mainP.innerHTML = strHtml;

}

    


