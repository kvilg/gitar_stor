
function createGitar(txt , namIn) {
    const mainP = document.getElementById('inNewParam');

    //console.log(txt);

    let obj = JSON.parse(txt);

    namI =namIn * 5;
    
    let strHtml = ``;

    //console.log(namI-5);
    //console.log(namI);

    //obj.git.length
    try{
        for(i = +(namI-5) ; i<+namI ; i++){
            if(i<obj.git.length){
                strHtml +=   `<div class="product_i">
                    <div class="product_info">
                        <div class="product_name">
                            `+obj.git[i].nameGit+`
                        </div>
                        <div class="product_price">
                            `+obj.git[i].priceGit+`
                        </div>
                        <div class="product_type">
                            `+obj.git[i].sensorsGit+`
                        </div>
                        <div class="product_sens">
                            `+obj.git[i].typeGit+`
                        </div>

                        <!-- 
                        <div class="btn_product_characteristic">

                        </div>
                        -->

                        </div>
                        <div class="product_img">

                        </div>

                    </div>`;
            }   
        }


    }catch{
        
    }
  
    mainP.innerHTML = strHtml;

    const btnSut = document.getElementById('product_next');


    let strHtmlNew = ``;
    
    

    //console.log(Math.ceil((+(obj.git.length)/5)));

    for(i = 1 ; i <= Math.ceil(+((obj.git.length)/5)) ; i++){
        if(+namIn == i){
            strHtmlNew += `  <div class="nam_next aktiv" id="next_param">`+i+`</div>`;
        }else{
            strHtmlNew += `  <div class="nam_next" id="next_param">`+i+`</div>`;
        }
    }
    btnSut.innerHTML = strHtmlNew; 


    const nextArrAA = document.querySelectorAll('.nam_next');


  
    //console.log("next");


    nextArrAA.forEach((next) => {
        next.addEventListener('click', () => {
            createGitar(txt,+(next.innerText));
        });
    });

    
   
   



}


function createSachDiv(txt) {

    const mainP = document.getElementById('disp_flex_slider');

    let obj = JSON.parse(txt);

    let minObj = obj.git[0].priceGit;
    let maxObj = 0;

    for (let i = 0; i < obj.git.length; i++) {
        if (maxObj<obj.git[i].priceGit) {
            maxObj = obj.git[i].priceGit;
        }
        if (minObj>obj.git[i].priceGit) {
            minObj = obj.git[i].priceGit;
        }
    
    }


    let strHtml = `  <div class="box_sahc">
    <input type="range" min="`+minObj+`" max="`+maxObj+`" value="`+minObj+`" class="slider" id="lower">
    <input type="range" min="`+minObj+`" max="`+maxObj+`" value="`+maxObj+`" class="slider" id="higher">

    <input type="text" id="input_text1" class="mt20" value="`+minObj+`">
    <input type="text" id="input_text2" class="mt20" value="`+maxObj+`">
    </div>


    <div class="box_sahc_y">
    <div class="dox_flex marg_bott">
        <input type="checkbox" id="gitarAkustic" value="Akustic">
        <span>акустическая</span>
    </div>
    <div class="dox_flex marg_bott">
        <input type="checkbox" id="gitarElectro">
        <span>электро</span>
    </div>
    <div class="dox_flex">
        <input type="checkbox" id="gitarElectroAkustic">
        <span>электро-акустика</span>
    </div>
</div>
<div class="box_sahc_y">
    <div class="dox_flex marg_bott">
        <input type="checkbox" id="gitarAktivSens">
        <span>активные датчики</span>
    </div>
    <div class="dox_flex marg_bott">
        <input type="checkbox" id="gitarPassivSens">
        <span>пасивные датчики</span>
    </div>
</div>`;

    mainP.innerHTML = strHtml; 

}